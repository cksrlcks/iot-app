import React from 'react';
import { Outlet as OutletComponenet } from 'react-router-dom';

export default function Outlet() {
    return <OutletComponenet />;
}
