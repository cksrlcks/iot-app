import React from 'react';

export default function Loading() {
    return (
        <div className="modal-loading">
            <div className="loading-spinner"></div>
        </div>
    );
}
